import { join, sep } from 'node:path'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { isFunctionName } from '../misuse-helpers.js'
import { validateFilePath } from '../../error-codes.js'
import { guardReadPath } from '../../path-guard.js'
import { attachStalenessWarning } from '../../staleness.js'

// r28-fix：诚实化——移除 parser 不支持的 .rb/.php，补 C/C++/Java/Bash
const SOURCE_EXTS = new Set(['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.mts', '.cts', '.py', '.go', '.rs', '.java', '.c', '.cpp', '.cc', '.cxx', '.hpp', '.hh', '.hxx', '.sh', '.bash'])

const _traceCache = new Map()
const _traceCacheMax = 200

function detectMisuse(symbol) {
  if (!symbol) return null
  if (isFunctionName(symbol)) {
    return {
      warning: 'likely_wrong_tool',
      suggestion: `"${symbol}" looks like a function/method name. For function impact analysis, use impact_analysis(symbol="${symbol}"). For line-level callers, use call_chain(line=N).`
    }
  }
  return null
}

export async function handle(args, context) {
  const { codeIndexService, getWorkspaceDir } = context
  const workspaceDir = args?.workspace_dir

  if (typeof workspaceDir !== 'string' || !workspaceDir) {
    return { error: 'missing_parameter', message: 'workspace_dir is required', suggestion: 'Provide the absolute path to the project root directory. Call reindex first.' }
  }

  const dbPath = join(getWorkspaceDir(workspaceDir), 'code-index.db')
  if (!existsSync(dbPath)) {
    return { error: 'workspace_not_indexed', message: `Workspace not indexed: ${workspaceDir}`, suggestion: `Call reindex(workspace_dir="${workspaceDir}") first` }
  }

  if (!codeIndexService) {
    return { error: 'service_unavailable', message: 'codeIndex service not available', suggestion: 'Check MCP server configuration and ensure code-index.js is loaded' }
  }

  await codeIndexService.initWorkspace(workspaceDir)

  const symbol = args?.symbol || ''
  const file = args?.file || ''
  const includeLiterals = !!args?.include_literals
  const maxResults = parseInt(args?.max_results) || 30

  if (!symbol) return { error: 'missing_parameter', message: 'symbol is required', suggestion: 'Provide a symbol name to trace (e.g. "MAX_RETRY_COUNT")' }
  if (!file) return { error: 'missing_parameter', message: 'file is required', suggestion: 'Provide a file path relative to workspace_dir where the symbol is defined' }

  const pathCheck = validateFilePath(file)
  if (pathCheck.blocked) {
    return { error: 'PATH_BLOCKED', code: 'PATH_BLOCKED', message: pathCheck.detail }
  }
  // r9(B1)：读侧 realpath 守卫（敏感文件链接名绕过 / 越界 symlink）
  const guardR = guardReadPath(workspaceDir, file)
  if (guardR.blocked) {
    return { error: 'PATH_BLOCKED', code: 'PATH_BLOCKED', message: guardR.detail }
  }

  const misuseWarning = detectMisuse(symbol)

  const absFilePath = join(workspaceDir, file)
  let fileMtime = 0
  try { fileMtime = statSync(absFilePath).mtimeMs } catch {}

  // R19-②：getReferences(symbol) 无 filePath 不走服务层出口——显式调服务层统一入口（带守卫）
  const staleness = await codeIndexService.ensureFreshFile?.(file)
  if (staleness?.auto_indexed) {
    try { fileMtime = statSync(absFilePath).mtimeMs } catch {}
  }

  const cacheKey = `${workspaceDir}\0${symbol}\0${file}\0${includeLiterals}\0${maxResults}\0${fileMtime}`
  const wasCached = _traceCache.has(cacheKey)
  if (wasCached) return _traceCache.get(cacheKey)

  const result = {
    symbol,
    file,
    value: null,
    value_line: null,
    dynamic: false,
    direct_references: [],
    truncated: false,
    suspected_literals: [],
    suggestion: null
  }

  const valueInfo = extractSymbolValue(absFilePath, symbol)
  if (valueInfo) {
    result.value = valueInfo.value
    result.value_line = valueInfo.line
    if (valueInfo.dynamic) {
      result.dynamic = true
      result.raw_value = valueInfo.raw
    }
  }

  // R22-④（审核修复）：max_results>500 时服务层默认 limit=500 会静默截断——显式传 limit=maxResults+1，
  // 服务层挂数组 truncated 属性（limit+1 探测），handler 的 length 判定随之正确
  const refs = await codeIndexService.getReferences(symbol, null, { limit: maxResults + 1 })
  // getReferences 返回 { path, kind, target_name, line }（11#1：SQL 补 r.line，
  // 此前漏选行号列 → 同文件多处引用无法定位）
  result.direct_references = (refs || []).slice(0, maxResults).map(r => ({
    file: r.path,
    kind: r.kind,
    target_name: r.target_name,
    line: r.line,
  }))
  result.truncated = (refs || []).length > maxResults

  if (result.direct_references.length === 0) {
    const textRefs = findSymbolNameRefs(workspaceDir, symbol, file, result.value_line, maxResults)
    // R22-④（审核修复）：扫描截断标注必须移出 length 判断——300 文件零命中但第 301+ 文件有命中时
    // textRefs 为空数组但 scanTruncated=true，旧实现标注丢失 → 空结果无提示（R22 要消除的同类漏报）
    if (textRefs.scanTruncated) result.search_truncated = true
    if (textRefs.length > 0) {
      result.direct_references = textRefs
      // R22-⑨：值名从 'text_fallback' 改为 'text_scan'——R22 已移除 references 的 text_fallback 机制，
      // trace-symbol 自己的文本扫描（r30 常量特性）是保留功能，旧值名误导（误以为已移除机制死代码）
      result.search_method = 'text_scan'
    }
  } else if (refs.every(r => r.kind === 'import')) {
    // r30：常量被 import 后 refs 只剩 import 行（变量读取不产 ref）——真实使用点全丢。
    // 旧实现只在 0 条时 fallback，常量永远 0 条以上（import）→ 读取点永远查不到。
    // 改：全部是 import 类 ref 时也跑文本扫描并去重合并。
    const textRefs = findSymbolNameRefs(workspaceDir, symbol, file, result.value_line, maxResults)
    // R22-④：同上——零命中 + 截断时也要标注（索引侧还有 import 结果，但文本侧可能不完整）
    if (textRefs.scanTruncated) result.search_truncated = true
    if (textRefs.length > 0) {
      const seen = new Set(result.direct_references.map(r => r.file + ':' + r.line))
      result.direct_references = [...result.direct_references, ...textRefs.filter(r => !seen.has(r.file + ':' + r.line))].slice(0, maxResults)
      result.search_method = 'index_plus_text'
    }
  }

  if (includeLiterals && valueInfo) {
    const value = valueInfo.value
    // r54(P0-8): 空串常量 `X = ""` 时 line.includes('') 恒真——每一行（含空行）都入列，仓库大文件内存爆炸。空串跳过 literal 扫描。
    if (value !== null && value !== undefined && String(value) !== '') {
      const literals = findLiteralReferences(workspaceDir, String(value), symbol)
      result.suspected_literals = literals.slice(0, maxResults)
      // R22-③：literal 扫描 200 文件/500 条上限截断标注
      if (literals.scanTruncated) result.literals_truncated = true
    }
  }

  if (result.suspected_literals && result.suspected_literals.length > 0 && result.value !== null) {
    result.suggestion = {
      action: 'replace_literal_with_symbol',
      symbol,
      count: result.suspected_literals.length
    }
  }

  const hasHardcodedCopies = result.suspected_literals?.length > 0 || result.direct_references?.length > 1
  result.next_step = hasHardcodedCopies
    ? `Use rename_symbol for atomic cross-file rename of "${symbol}".`
    : `Single definition. Use edit_transaction to modify "${symbol}".`

  attachStalenessWarning(result, staleness)

  if (misuseWarning) {
    result.misuse_warning = misuseWarning
  }

  _traceCache.set(cacheKey, result)
  if (_traceCache.size > _traceCacheMax) {
    const oldest = _traceCache.keys().next().value
    _traceCache.delete(oldest)
  }

  return result
}

function extractSymbolValue(absPath, symbol) {
  try {
    if (!existsSync(absPath)) return null
    const content = readFileSync(absPath, 'utf-8')
    const lines = content.split('\n')

    const assignmentRegex = new RegExp(`^(?:\\s*\\w+\\s+)?${escapeRegex(symbol)}\\s*(?::\\s*\\w+)?\\s*=\\s*(.+)`)
    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(assignmentRegex)
      if (match) {
        let value = match[1].trim().replace(/,$/, '').replace(/#.*$/, '').replace(/;+$/, '').trim()
        if (value.length > 0 && value.length < 200) {
          if (/^[a-zA-Z_]\w*\(/.test(value) || value.includes(' lambda ') || value.includes(' new ')) {
            return { value: null, dynamic: true, raw: value, line: i + 1 }
          }
          try { value = JSON.parse(value) } catch {}
          return { value, line: i + 1 }
        }
      }
    }
    return null
  } catch {
    return null
  }
}

function findLiteralReferences(workspaceDir, literalValue, excludeSymbol, maxFiles = 200) {
  const results = []
  const scanned = { files: 0 }

  try {
    walkDir(workspaceDir, workspaceDir, literalValue, excludeSymbol, results, scanned, maxFiles)
  } catch {}

  // R22-③（审核补全）：200 文件上限 + 500 条硬上限截断不再静默
  if (scanned.files >= maxFiles || results.length >= 500) results.scanTruncated = true

  results.sort((a, b) => b.confidence - a.confidence)
  return results
}

function walkDir(baseDir, currentDir, literalValue, excludeSymbol, results, scanned, maxFiles) {
  // r54(P0-8): results 无上限——短 literal 在大仓库可收集数万条撑爆内存。硬上限 500（调用方再 slice 到 maxResults）。
  if (scanned.files >= maxFiles || results.length >= 500) return
  let entries
  try { entries = readdirSync(currentDir, { withFileTypes: true }) } catch { return }

  for (const entry of entries) {
    if (scanned.files >= maxFiles || results.length >= 500) break
    if (entry.name.startsWith('.') || entry.name === 'node_modules' || entry.name === '.ai-transactions') continue
    const fullPath = join(currentDir, entry.name)

    if (entry.isDirectory()) {
      walkDir(baseDir, fullPath, literalValue, excludeSymbol, results, scanned, maxFiles)
    } else if (entry.isFile()) {
      const ext = fullPath.slice(fullPath.lastIndexOf('.'))
      if (!SOURCE_EXTS.has(ext)) continue
      scanned.files++

      try {
        const content = readFileSync(fullPath, 'utf-8')
        const lines = content.split('\n')
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i]
          if (!line.includes(literalValue) || line.includes(excludeSymbol)) continue
          if (!hasBoundaryMatch(line, literalValue)) continue
          if (isInCommentOrString(line, literalValue)) continue
          const confidence = calcConfidence(line, literalValue)
          if (confidence >= 0.5) {
            const relPath = (fullPath.startsWith(baseDir + sep) ? fullPath.slice(baseDir.length + 1) : fullPath).replace(/\\/g, '/')
            results.push({ file: relPath, line: i + 1, context: line.trim(), confidence: Math.round(confidence * 100) / 100, level: confidence >= 0.8 ? 'high' : 'medium' })
          }
        }
      } catch {}
    }
  }
}

function isInCommentOrString(line, value) {
  const commentIdx = line.indexOf('#')
  const strIdx = line.indexOf('"')
  const strIdx2 = line.indexOf("'")
  const valueIdx = line.indexOf(value)
  if (commentIdx >= 0 && valueIdx > commentIdx) return true
  if (strIdx >= 0 && valueIdx > strIdx) {
    const endStr = line.indexOf('"', strIdx + 1)
    if (endStr < 0 || valueIdx < endStr) return true
  }
  if (strIdx2 >= 0 && valueIdx > strIdx2) {
    const endStr = line.indexOf("'", strIdx2 + 1)
    if (endStr < 0 || valueIdx < endStr) return true
  }
  return false
}

function calcConfidence(line, value) {
  let score = 1.0
  if (line.includes('=') || line.includes('==')) score -= 0.2
  if (line.trimStart().startsWith('#')) score -= 0.5
  if (line.trimStart().startsWith('//')) score -= 0.5
  if (line.includes('print') || line.includes('log') || line.includes('console.')) score -= 0.2
  if (line.includes('def ') || line.includes('function ')) score -= 0.3
  if (line.includes('assert')) score -= 0.1
  const count = line.split(value).length - 1
  if (count > 2) score -= 0.2
  return Math.max(0, score)
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function hasBoundaryMatch(line, value) {
  if (/^\w+$/.test(value)) {
    // R17-8：`(^|[^\w])` 替代 `\b`——`\b` 对 Unicode（中文）符号名不生效
    const re = new RegExp(`(^|[^\\w])${escapeRegex(value)}([^\\w]|$)`)
    return re.test(line)
  }
  return line.includes(value)
}

function findSymbolNameRefs(workspaceDir, symbol, excludeFile, excludeLine, maxResults) {
  const results = []
  // R17-8：`(^|[^\w])` 替代 `\b`——中文/Unicode 符号名边界正确匹配
  const re = new RegExp(`(^|[^\\w])${escapeRegex(symbol)}([^\\w]|$)`)
  const scanned = { files: 0 }
  walkDirForSymbol(workspaceDir, workspaceDir, re, excludeFile, excludeLine, results, scanned, 300, maxResults)
  // R22-③（审核补全）：300 文件上限截断不再静默——挂数组属性，与 getReferences.truncated 同款模式
  // （references 的同类静默扫描已随 R22 删除，trace-symbol 的文本扫描是 r30 特性保留，但截断必须标注）
  if (scanned.files >= 300) results.scanTruncated = true
  return results
}

function walkDirForSymbol(baseDir, currentDir, re, excludeFile, excludeLine, results, scanned, maxFiles, maxResults) {
  if (scanned.files >= maxFiles || results.length >= maxResults) return
  let entries
  try { entries = readdirSync(currentDir, { withFileTypes: true }) } catch { return }
  for (const entry of entries) {
    if (scanned.files >= maxFiles || results.length >= maxResults) break
    if (entry.name.startsWith('.') || entry.name === 'node_modules') continue
    const fullPath = join(currentDir, entry.name)
    if (entry.isDirectory()) {
      walkDirForSymbol(baseDir, fullPath, re, excludeFile, excludeLine, results, scanned, maxFiles, maxResults)
    } else if (entry.isFile()) {
      const ext = fullPath.slice(fullPath.lastIndexOf('.'))
      if (!SOURCE_EXTS.has(ext)) continue
      scanned.files++
      const relPath = (fullPath.startsWith(baseDir + sep) ? fullPath.slice(baseDir.length + 1) : fullPath).replace(/\\/g, '/')
      // 10（F3）：不再整文件排除定义文件——同文件引用（常量在自己文件里被用）旧实现全漏；只跳定义行本身
      const isDefFile = relPath === excludeFile
      try {
        const content = readFileSync(fullPath, 'utf-8')
        const lines = content.split('\n')
        for (let i = 0; i < lines.length; i++) {
          if (isDefFile && excludeLine != null && i + 1 === excludeLine) continue
          if (re.test(lines[i])) {
            results.push({ file: relPath, line: i + 1, context: lines[i].trim() })
            if (results.length >= maxResults) break
          }
        }
      } catch {}
    }
  }
}
